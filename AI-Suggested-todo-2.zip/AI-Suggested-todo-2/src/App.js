import React, { useState, useEffect } from "react";
import axios from "axios";

const App = () => {
    return (
        <div className="container">
            <h1>AI-Powered To-Do List</h1>
            <TaskManager />
        </div>
    );
};

const TaskManager = () => {
    const [tasks, setTasks] = useState([]);
    const [task, setTask] = useState("");
    const [suggestion, setSuggestion] = useState("");

    // Load tasks from local storage
    useEffect(() => {
        const storedTasks = JSON.parse(localStorage.getItem("tasks")) || [];
        setTasks(storedTasks);
    }, []);

    // Save tasks to local storage whenever tasks change
    useEffect(() => {
        localStorage.setItem("tasks", JSON.stringify(tasks));
    }, [tasks]);

    // Add a task
    const addTask = () => {
        if (task.trim() === "") {
            alert("Task cannot be empty!");
            return;
        }
        const newTask = { id: Date.now(), task };
        setTasks([...tasks, newTask]);
        setTask(""); // Clear input field
    };

    // Get AI-powered task suggestion
    const getSuggestion = async () => {
        const API_KEY = "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"; // Secured key
        if (!API_KEY) {
            console.error("Missing OpenAI API key.");
            return;
        }
        try {
            const response = await axios.post(
                "https://api.openai.com/v1/completions",
                {
                    model: "gpt-3.5-turbo",
                    prompt: `Suggest a task based on: ${task}`,
                    max_tokens: 50
                },
                {
                    headers: {
                        "Authorization": `Bearer ${API_KEY}`,
                        "Content-Type": "application/json"
                    }
                }
            );
            setSuggestion(response.data.choices[0].text.trim());
        } catch (error) {
            console.error("Error fetching suggestion:", error);
        }
    };

    // Delete a task
    const deleteTask = (id) => {
        const updatedTasks = tasks.filter(task => task.id !== id);
        setTasks(updatedTasks);
    };

    return (
        <div>
            <input
                value={task}
                onChange={(e) => setTask(e.target.value)}
                placeholder="Enter a task"
            />
            <button onClick={addTask}>Add Task</button>
            <button onClick={getSuggestion}>AI Suggest Task</button>
            <p>Suggestion: {suggestion}</p>
            <ul>
                {tasks.map((t) => (
                    <li key={t.id}>
                        {t.task}
                        <button onClick={() => deleteTask(t.id)}>❌</button>
                    </li>
                ))}
            </ul>
        </div>
    );
};

export default App;
